# 1clickhuawei


- Run installation script:
```
bash -c "$(wget -qO - 'https://raw.githubusercontent.com/saputribosen/1clickhuawei/refs/heads/main/huaweisetup.sh')"
```
